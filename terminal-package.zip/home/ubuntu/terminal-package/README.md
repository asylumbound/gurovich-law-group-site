# Gurovich Law Group - Terminal

A standalone legal research assistant with RAG (Retrieval-Augmented Generation) capabilities for the Gurovich Law Group case management system.

---

## Overview

The Terminal is a staff-only application that provides:

- **AI-Powered Chat** - Conversational interface for legal research
- **Document RAG** - Search across uploaded case documents
- **Case Law Search** - CourtListener API integration for federal/state cases
- **Statute Lookup** - California statute reference library
- **Knowledge Concepts** - Legal cause of action templates with proof matrices
- **Discovery Tools** - Task creation and draft document generation

---

## Quick Start

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Run tests
pnpm test

# Build for production
pnpm build
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [SETUP_INSTRUCTIONS.md](docs/SETUP_INSTRUCTIONS.md) | Complete deployment guide |
| [DATABASE_SCHEMA.md](docs/DATABASE_SCHEMA.md) | Supabase table definitions |
| [ENVIRONMENT_VARIABLES.md](docs/ENVIRONMENT_VARIABLES.md) | Required configuration |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Terminal Frontend                         │
│  (React + tRPC Client + Streamdown + Mermaid)               │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ CORS
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Main Site API                             │
│  (Express + tRPC Server)                                    │
│  https://www.gurovichlawgroup.com/api/trpc                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Supabase                                  │
│  - PostgreSQL Database (shared)                             │
│  - Storage Buckets (documents)                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Key Features

### 1. Chat Sessions

Each chat session is scoped to a specific intake (case/matter). Sessions persist across browser sessions and can be:

- Favorited for quick access
- Archived (soft delete)
- Exported to PDF

### 2. RAG Document Search

Uploaded documents are automatically processed:
1. PDF text extraction
2. Chunking and indexing
3. Keyword search across all intake documents
4. Relevant snippets included in AI context

### 3. Case Law Integration

CourtListener API provides access to:
- Federal court opinions
- State court opinions (California focus)
- Full-text search with court filtering
- Direct links to source documents

### 4. Knowledge Concepts (KC) Library

Pre-built legal templates for:
- Personal Injury (negligence, premises liability, etc.)
- Criminal Defense (DUI, assault, theft, etc.)
- Employment Law (discrimination, wrongful termination, etc.)
- Tenant Rights (habitability, unlawful eviction, etc.)
- Civil Litigation (breach of contract, defamation, etc.)

Each KC includes:
- Required elements to prove
- Evidence type requirements
- Proof matrix tracking

### 5. Discovery Accelerator

AI-assisted discovery tools:
- **Create Task** - Generate discovery tasks from chat
- **Save Draft** - Save AI-generated documents as drafts

---

## Environment Variables

Required secrets (set in Manus Settings → Secrets):

| Variable | Description |
|----------|-------------|
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Public anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key (server only) |
| `OPENAI_API_KEY` | OpenAI API key |
| `COURTLISTENER_API_TOKEN` | CourtListener API token |

See [ENVIRONMENT_VARIABLES.md](docs/ENVIRONMENT_VARIABLES.md) for complete list.

---

## Database Tables

The Terminal uses these Supabase tables (shared with main site):

| Table | Purpose |
|-------|---------|
| `terminal_sessions` | Chat session storage |
| `terminal_messages` | Message history |
| `upload_text` | Extracted document text |
| `discovery_tasks` | Task management |
| `discovery_drafts` | Draft documents |
| `knowledge_concepts` | KC library |
| `kc_templates` | Template definitions |
| `statutes` | Statute cache |

See [DATABASE_SCHEMA.md](docs/DATABASE_SCHEMA.md) for complete schema.

---

## Deployment

### Option 1: Manus Hosting (Recommended)

1. Create new Manus project
2. Upload this package
3. Configure secrets
4. Add custom domain: `terminal.gurovichlawgroup.com`
5. Publish

### Option 2: Vercel

1. Build: `VITE_BUILD_TARGET=terminal pnpm build`
2. Deploy `dist/` to Vercel
3. Configure environment variables
4. Add custom domain

See [SETUP_INSTRUCTIONS.md](docs/SETUP_INSTRUCTIONS.md) for detailed steps.

---

## Testing

```bash
# Run all tests
pnpm test

# Run specific test file
pnpm test -- server/terminal.test.ts

# Run with coverage
pnpm test -- --coverage
```

Test files:
- `server/terminal.test.ts` - Terminal procedures (17 tests)
- `server/kc-library.test.ts` - KC library (11 tests)
- `server/supabase.test.ts` - Database connection (2 tests)
- `server/api-keys.test.ts` - API validation (4 tests)

---

## Support

- **Manus Platform:** [help.manus.im](https://help.manus.im)
- **Supabase:** [supabase.com/docs](https://supabase.com/docs)
- **OpenAI:** [platform.openai.com/docs](https://platform.openai.com/docs)
- **CourtListener:** [courtlistener.com/api](https://www.courtlistener.com/api)

---

## License

Proprietary - Gurovich Law Group, APC
