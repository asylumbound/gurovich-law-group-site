# Environment Variables

This document lists all environment variables required for the Terminal application.

---

## Overview

The Terminal requires environment variables for:
1. **Supabase** - Database and storage
2. **OpenAI** - LLM for chat and embeddings
3. **CourtListener** - Legal case search API
4. **Manus Platform** - OAuth and built-in services
5. **Main Site API** - Cross-origin API access

---

## Required Variables

### Supabase Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `SUPABASE_URL` | Supabase project URL | `https://abc123.supabase.co` |
| `SUPABASE_ANON_KEY` | Public anon key for client | `eyJhbGciOiJIUzI1NiIs...` |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key (server only) | `eyJhbGciOiJIUzI1NiIs...` |

**How to obtain:**
1. Go to your Supabase project dashboard
2. Navigate to Settings → API
3. Copy the URL and keys

### OpenAI Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key for LLM calls | `sk-proj-...` |

**How to obtain:**
1. Go to [platform.openai.com](https://platform.openai.com)
2. Navigate to API Keys
3. Create a new key

**Usage:** Used for chat completions, embeddings generation, and document analysis.

### CourtListener API

| Variable | Description | Example |
|----------|-------------|---------|
| `COURTLISTENER_API_TOKEN` | CourtListener API token | `12ea763b9f0b6b959...` |

**How to obtain:**
1. Create account at [courtlistener.com](https://www.courtlistener.com)
2. Go to Profile → API Tokens
3. Generate a new token

**Usage:** Used for searching federal and state case law.

### Manus Platform (Auto-Injected)

These are automatically provided by Manus when deployed:

| Variable | Description |
|----------|-------------|
| `VITE_APP_ID` | Manus OAuth application ID |
| `OAUTH_SERVER_URL` | Manus OAuth backend URL |
| `VITE_OAUTH_PORTAL_URL` | Manus login portal URL |
| `JWT_SECRET` | Session cookie signing secret |
| `OWNER_OPEN_ID` | Project owner's Manus ID |
| `OWNER_NAME` | Project owner's display name |
| `BUILT_IN_FORGE_API_URL` | Manus built-in APIs URL |
| `BUILT_IN_FORGE_API_KEY` | Manus built-in APIs token |
| `VITE_FRONTEND_FORGE_API_URL` | Frontend Forge API URL |
| `VITE_FRONTEND_FORGE_API_KEY` | Frontend Forge API token |

**Note:** Do not manually set these; they are injected by the Manus platform.

### Main Site API Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `VITE_MAIN_SITE_API_URL` | Main site API endpoint | `https://www.gurovichlawgroup.com/api/trpc` |

**Usage:** If Terminal is deployed separately, it needs to know where to send API requests.

---

## CORS Configuration

When deploying Terminal to a subdomain, the main site must allow CORS from the Terminal domain.

In the main site's `server/_core/index.ts`:

```typescript
const allowedOrigins = [
  "https://www.gurovichlawgroup.com",
  "https://gurovichlawgroup.com",
  "https://terminal.gurovichlawgroup.com", // Add Terminal subdomain
];
```

---

## .env.example Template

Create a `.env` file with these variables:

```bash
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# OpenAI
OPENAI_API_KEY=sk-proj-your-key

# CourtListener
COURTLISTENER_API_TOKEN=your-token

# Main Site API (for standalone deployment)
VITE_MAIN_SITE_API_URL=https://www.gurovichlawgroup.com/api/trpc

# Manus Platform (auto-injected, do not set manually)
# VITE_APP_ID=
# OAUTH_SERVER_URL=
# VITE_OAUTH_PORTAL_URL=
# JWT_SECRET=
```

---

## Security Notes

1. **Never commit `.env` files** to version control
2. **Service role key** should only be used server-side
3. **API keys** should be rotated periodically
4. **Use Manus Secrets** panel to manage sensitive values in production

---

## Validation

After setting environment variables, verify they work:

```bash
# Run the test suite
pnpm test

# Check specific integrations
pnpm test -- --grep "Supabase"
pnpm test -- --grep "OpenAI"
pnpm test -- --grep "CourtListener"
```

All tests should pass if environment variables are correctly configured.
