# Terminal Standalone Deployment Guide

This document provides complete step-by-step instructions for deploying the Terminal as a standalone Manus project at `terminal.gurovichlawgroup.com`.

---

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Step 1: Create New Manus Project](#step-1-create-new-manus-project)
4. [Step 2: Upload Terminal Code](#step-2-upload-terminal-code)
5. [Step 3: Configure Environment Variables](#step-3-configure-environment-variables)
6. [Step 4: Configure Database Connection](#step-4-configure-database-connection)
7. [Step 5: Install Dependencies](#step-5-install-dependencies)
8. [Step 6: Test the Application](#step-6-test-the-application)
9. [Step 7: Configure Custom Domain](#step-7-configure-custom-domain)
10. [Step 8: Publish and Verify](#step-8-publish-and-verify)
11. [Troubleshooting](#troubleshooting)

---

## Overview

The Terminal is a staff-only legal research assistant with RAG (Retrieval-Augmented Generation) capabilities. It requires heavy JavaScript libraries (mermaid, streamdown) that are isolated from the main marketing site to keep the public-facing bundle lightweight.

**Architecture:**

| Component | Main Site | Terminal |
|-----------|-----------|----------|
| Domain | gurovichlawgroup.com | terminal.gurovichlawgroup.com |
| Bundle Size | 637 KB | 3.2 MB |
| Target Users | Public | Staff only |
| Database | Supabase (shared) | Supabase (shared) |
| API | /api/trpc | Calls main site API via CORS |

---

## Prerequisites

Before starting, ensure you have:

1. **Manus Account** with project creation permissions
2. **Supabase Credentials** from the main site:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
3. **API Keys**:
   - `OPENAI_API_KEY` (for LLM chat)
   - `COURTLISTENER_API_TOKEN` (for case law search)
4. **DNS Access** to gurovichlawgroup.com (DreamHost or your registrar)
5. **Main Site Published** at gurovichlawgroup.com with CORS configured

---

## Step 1: Create New Manus Project

1. Log in to Manus at [manus.im](https://manus.im)
2. Click **New Project**
3. Name it: `Gurovich Terminal`
4. Select template: **Web App (tRPC + Manus Auth + Database)**
5. Wait for project initialization

**Important:** Choose the full-stack template, not static, because Terminal needs server-side tRPC procedures.

---

## Step 2: Upload Terminal Code

### Option A: Direct File Upload

1. Download the `terminal-package.zip` file
2. Extract to your local machine
3. In Manus, open the Code panel
4. Delete default template files
5. Upload all files from the extracted package

### Option B: Git Clone (if connected to GitHub)

```bash
# In Manus terminal
git clone https://github.com/your-repo/terminal-package.git .
```

### File Structure

After upload, your project should have:

```
client/
├── index.html           # Terminal entry point
├── src/
│   ├── main.tsx         # React bootstrap with tRPC
│   ├── App.tsx          # Terminal routes
│   ├── pages/
│   │   └── Terminal.tsx # Main Terminal component
│   ├── components/      # UI components
│   └── lib/
│       └── trpc.ts      # tRPC client (points to main site)
server/
├── routers.ts           # tRPC router definitions
├── trpc/
│   └── routers/
│       └── terminal.ts  # Terminal procedures
├── storage.ts           # Supabase storage helpers
└── db.ts                # Database helpers
shared/
├── types.ts             # Shared TypeScript types
└── const.ts             # Shared constants
drizzle/
└── schema.ts            # Database schema (reference only)
supabase/
└── migrations/          # SQL migrations (already applied)
```

---

## Step 3: Configure Environment Variables

In Manus, go to **Settings → Secrets** and add these variables:

### Required Secrets

| Variable | Value | Notes |
|----------|-------|-------|
| `SUPABASE_URL` | `https://[your-project].supabase.co` | From main site |
| `SUPABASE_ANON_KEY` | `eyJhbGciOiJIUzI1NiIs...` | From main site |
| `SUPABASE_SERVICE_ROLE_KEY` | `eyJhbGciOiJIUzI1NiIs...` | From main site |
| `OPENAI_API_KEY` | `sk-proj-...` | Your OpenAI key |
| `COURTLISTENER_API_TOKEN` | `12ea763b9f0b6b959...` | From CourtListener |

### Auto-Injected by Manus

These are automatically provided (do not set manually):

- `VITE_APP_ID`
- `OAUTH_SERVER_URL`
- `VITE_OAUTH_PORTAL_URL`
- `JWT_SECRET`
- `OWNER_OPEN_ID`
- `OWNER_NAME`
- `BUILT_IN_FORGE_API_URL`
- `BUILT_IN_FORGE_API_KEY`

---

## Step 4: Configure Database Connection

The Terminal connects to the **same Supabase database** as the main site. No additional database setup is needed.

### Verify Tables Exist

In Supabase Dashboard → SQL Editor, run:

```sql
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
  'terminal_sessions',
  'terminal_messages',
  'upload_text',
  'discovery_tasks',
  'discovery_drafts',
  'knowledge_concepts',
  'kc_templates',
  'kc_template_assignments',
  'evidence_types',
  'statutes'
);
```

All 10 tables should be listed. If any are missing, apply the migrations from `supabase/migrations/`.

### Tables Used by Terminal

| Table | Access | Purpose |
|-------|--------|---------|
| `terminal_sessions` | Read/Write | Chat session storage |
| `terminal_messages` | Read/Write | Message history |
| `upload_text` | Read | Document text for RAG |
| `discovery_tasks` | Read/Write | Task management |
| `discovery_drafts` | Read/Write | Draft documents |
| `knowledge_concepts` | Read | KC library lookup |
| `kc_templates` | Read | Template elements |
| `kc_template_assignments` | Read | KC-template links |
| `evidence_types` | Read | Evidence categorization |
| `statutes` | Read | Statute lookup |
| `intakes` | Read | Case/matter data |
| `intake_uploads` | Read | File metadata |

---

## Step 5: Install Dependencies

In Manus terminal, run:

```bash
pnpm install
```

This installs all required packages including:

- React 18
- tRPC client
- Streamdown (markdown rendering with mermaid)
- Lucide React icons
- Tailwind CSS

---

## Step 6: Test the Application

### Start Development Server

```bash
pnpm dev
```

### Run Tests

```bash
pnpm test
```

All tests should pass. Key tests to verify:

- `server/terminal.test.ts` - Terminal procedures
- `server/kc-library.test.ts` - KC library integration
- `server/supabase.test.ts` - Database connection
- `server/api-keys.test.ts` - API key validation

### Manual Testing

1. Open the dev server URL in browser
2. Log in with Manus OAuth
3. Select an intake from the dropdown
4. Send a test message
5. Verify response with citations

---

## Step 7: Configure Custom Domain

### Step 7a: Get Manus Project URL

After creating the project, note the Manus URL:
`https://gurovich-terminal-xxxx.manus.space`

### Step 7b: Configure DNS at DreamHost

1. Log in to DreamHost panel
2. Go to **Domains → Manage Domains**
3. Find `gurovichlawgroup.com`
4. Click **DNS** settings
5. Add a **CNAME record**:
   - **Name:** `terminal`
   - **Value:** `gurovich-terminal-xxxx.manus.space`
   - **TTL:** 3600

### Step 7c: Configure Domain in Manus

1. In Manus, go to **Settings → Domains**
2. Click **Add Custom Domain**
3. Enter: `terminal.gurovichlawgroup.com`
4. Follow verification steps

DNS propagation takes 5-30 minutes.

---

## Step 8: Publish and Verify

### Create Checkpoint

Before publishing, save a checkpoint:

1. In Manus, make any final changes
2. Click **Save Checkpoint** with description
3. Verify all tests pass

### Publish

1. Click the **Publish** button in Manus header
2. Wait for deployment to complete
3. Visit `https://terminal.gurovichlawgroup.com`

### Verify Functionality

1. **Login:** OAuth redirects correctly
2. **Intake Selection:** Dropdown shows available intakes
3. **Chat:** Messages send and receive
4. **Citations:** Document citations are clickable
5. **KC Library:** Knowledge concepts load
6. **Case Law:** CourtListener search works

---

## Troubleshooting

### White Screen / JavaScript Error

**Cause:** Mermaid library failed to initialize.

**Solution:**
1. Check browser console for errors
2. Verify all chunks loaded (Network tab)
3. Clear browser cache and retry

### CORS Errors

**Cause:** Main site not allowing Terminal subdomain.

**Solution:**
1. Verify main site CORS includes `terminal.gurovichlawgroup.com`
2. Redeploy main site after CORS update
3. Check browser Network tab for blocked requests

### Login Doesn't Persist

**Cause:** Cookies not shared across subdomains.

**Solution:**
1. Ensure both sites use same `VITE_APP_ID`
2. Check cookie domain is `.gurovichlawgroup.com` (with dot)
3. Verify third-party cookies are allowed in browser

### Database Connection Failed

**Cause:** Incorrect Supabase credentials.

**Solution:**
1. Verify `SUPABASE_URL` matches main site
2. Check `SUPABASE_SERVICE_ROLE_KEY` is correct
3. Run `pnpm test -- --grep "Supabase"` to validate

### API Calls Timeout

**Cause:** Main site API not reachable.

**Solution:**
1. Verify main site is published and running
2. Check `VITE_MAIN_SITE_API_URL` if using separate API
3. Test API directly: `curl https://www.gurovichlawgroup.com/api/trpc`

### KC Library Empty

**Cause:** Knowledge concepts not seeded.

**Solution:**
1. Run seed script: `node scripts/seed-kc-library.mjs`
2. Verify in Supabase: `SELECT COUNT(*) FROM knowledge_concepts`
3. Should return 56 rows

---

## Support

For issues with:

- **Manus Platform:** Submit request at [help.manus.im](https://help.manus.im)
- **Supabase:** Check [supabase.com/docs](https://supabase.com/docs)
- **Application Bugs:** Review logs in `.manus-logs/` directory

---

## Quick Reference

| Item | Value |
|------|-------|
| Main Site | https://www.gurovichlawgroup.com |
| Terminal | https://terminal.gurovichlawgroup.com |
| API Endpoint | https://www.gurovichlawgroup.com/api/trpc |
| Database | Supabase (shared with main site) |
| Auth | Manus OAuth |
| Bundle Size | ~3.2 MB (lazy loaded) |
