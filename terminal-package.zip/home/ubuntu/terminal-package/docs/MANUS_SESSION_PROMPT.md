# Manus Session Prompt for Terminal Deployment

Copy and paste this prompt when starting a new Manus session to deploy the Terminal.

---

## Prompt

```
I need to deploy the Gurovich Law Group Terminal as a standalone Manus project.

**Project Overview:**
- Name: Gurovich Terminal
- Domain: terminal.gurovichlawgroup.com
- Purpose: Staff-only legal research assistant with RAG capabilities
- Stack: React 18, TypeScript, tRPC, Tailwind CSS, Streamdown (mermaid)

**What I Have:**
- A ZIP file containing the complete Terminal codebase
- Supabase credentials (shared with main site at gurovichlawgroup.com)
- OpenAI API key
- CourtListener API token

**What I Need You To Do:**

1. **Initialize Project**
   - Create a new Manus project using the "Web App (tRPC + Manus Auth + Database)" template
   - Name it "Gurovich Terminal"

2. **Upload Code**
   - I will upload the terminal-package.zip file
   - Extract and replace the default template files with the package contents

3. **Configure Environment Variables**
   - I will provide the following secrets:
     - SUPABASE_URL
     - SUPABASE_ANON_KEY
     - SUPABASE_SERVICE_ROLE_KEY
     - OPENAI_API_KEY
     - COURTLISTENER_API_TOKEN

4. **Verify Database Connection**
   - The Terminal connects to the SAME Supabase database as the main site
   - All required tables already exist (terminal_sessions, terminal_messages, etc.)
   - Run the test suite to verify: `pnpm test`

5. **Configure Custom Domain**
   - Add terminal.gurovichlawgroup.com as a custom domain
   - I have already configured the DNS CNAME record at DreamHost

6. **Test and Publish**
   - Verify the dev server works
   - Run all tests (should be 71 passing)
   - Create a checkpoint
   - Publish to production

**Important Notes:**
- The Terminal calls the main site API via CORS (already configured)
- Authentication uses Manus OAuth (shared with main site)
- The bundle is ~3.2 MB due to mermaid/streamdown (this is expected)
- Do NOT modify the main site - this is a separate project

**Main Site Reference:**
- URL: https://www.gurovichlawgroup.com
- API: https://www.gurovichlawgroup.com/api/trpc
- CORS is already configured to allow terminal.gurovichlawgroup.com

Let me know when you're ready and I'll upload the ZIP file.
```

---

## After Deployment Checklist

After the new session completes deployment, verify:

- [ ] Terminal loads at https://terminal.gurovichlawgroup.com
- [ ] OAuth login redirects correctly
- [ ] Intake dropdown shows available cases
- [ ] Chat messages send and receive
- [ ] Document citations are clickable
- [ ] KC Library panel loads knowledge concepts
- [ ] CourtListener search returns results
- [ ] Session favorites/archive work
- [ ] PDF export generates correctly

---

## Troubleshooting Commands

If issues arise, use these commands in the Manus terminal:

```bash
# Check environment variables are set
env | grep SUPABASE
env | grep OPENAI
env | grep COURTLISTENER

# Test database connection
pnpm test -- --grep "Supabase"

# Test API keys
pnpm test -- --grep "API Key"

# Check build output
pnpm build && ls -la dist/

# View server logs
cat .manus-logs/devserver.log | tail -50

# View browser console logs
cat .manus-logs/browserConsole.log | tail -50
```

---

## DNS Configuration Reference

At DreamHost (or your DNS provider):

| Type | Name | Value | TTL |
|------|------|-------|-----|
| CNAME | terminal | [manus-project-url].manus.space | 3600 |

Replace `[manus-project-url]` with the actual Manus project URL provided after project creation.

---

## Secrets to Provide

When the new session asks for secrets, provide these values:

1. **SUPABASE_URL**: `https://[your-project-ref].supabase.co`
2. **SUPABASE_ANON_KEY**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
3. **SUPABASE_SERVICE_ROLE_KEY**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
4. **OPENAI_API_KEY**: `sk-proj-...`
5. **COURTLISTENER_API_TOKEN**: `12ea763b9f0b6b959...`

Get these from:
- Supabase: Dashboard → Settings → API
- OpenAI: platform.openai.com → API Keys
- CourtListener: courtlistener.com → Profile → API Tokens
