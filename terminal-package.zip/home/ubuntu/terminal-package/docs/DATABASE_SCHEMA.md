# Terminal Database Schema

This document describes all Supabase tables required for the Terminal application.

---

## Overview

The Terminal uses Supabase (PostgreSQL) for storing sessions, messages, documents, and knowledge concepts. All tables are created via SQL migrations in the `supabase/migrations/` folder.

---

## Core Tables

### terminal_sessions

Stores chat sessions for each intake/matter.

```sql
CREATE TABLE terminal_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL REFERENCES intakes(id),
  user_id TEXT NOT NULL,
  title TEXT DEFAULT 'New Session',
  is_favorite BOOLEAN DEFAULT FALSE,
  is_archived BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_terminal_sessions_user_id ON terminal_sessions(user_id);
CREATE INDEX idx_terminal_sessions_intake_id ON terminal_sessions(intake_id);
CREATE INDEX idx_terminal_sessions_created_at ON terminal_sessions(created_at DESC);
```

### terminal_messages

Stores individual messages within sessions.

```sql
CREATE TABLE terminal_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES terminal_sessions(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content TEXT NOT NULL,
  citations JSONB DEFAULT '[]',
  suggested_actions JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_terminal_messages_session_id ON terminal_messages(session_id);
CREATE INDEX idx_terminal_messages_session_created ON terminal_messages(session_id, created_at);
```

### upload_text

Stores extracted text from uploaded documents for RAG search.

```sql
CREATE TABLE upload_text (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  upload_id UUID NOT NULL,
  intake_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  storage_path TEXT,
  chunk_index INTEGER NOT NULL,
  content TEXT NOT NULL,
  embedding VECTOR(1536),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_upload_text_intake_id ON upload_text(intake_id);
CREATE INDEX idx_upload_text_upload_id ON upload_text(upload_id);
```

### case_memory

Stores persistent memory/notes for each intake.

```sql
CREATE TABLE case_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL REFERENCES intakes(id),
  category TEXT NOT NULL,
  content TEXT NOT NULL,
  source TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_case_memory_intake_id ON case_memory(intake_id);
```

---

## Discovery Tables

### discovery_tasks

Tracks discovery tasks created from Terminal conversations.

```sql
CREATE TABLE discovery_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  due_date TIMESTAMPTZ,
  assigned_to TEXT,
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_discovery_tasks_intake_id ON discovery_tasks(intake_id);
```

### discovery_drafts

Stores draft documents generated from Terminal.

```sql
CREATE TABLE discovery_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  draft_type TEXT NOT NULL,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'review', 'final', 'sent')),
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_discovery_drafts_intake_id ON discovery_drafts(intake_id);
```

---

## Knowledge Concepts (KC) Library

### knowledge_concepts

Master list of legal causes of action and defenses.

```sql
CREATE TABLE knowledge_concepts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  domain TEXT NOT NULL CHECK (domain IN ('civil', 'criminal')),
  jurisdiction TEXT NOT NULL CHECK (jurisdiction IN ('CA', 'federal', 'both')),
  category TEXT NOT NULL,
  description TEXT,
  statute_reference TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### kc_templates

Templates defining elements required to prove each KC.

```sql
CREATE TABLE kc_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  domain TEXT NOT NULL,
  jurisdiction TEXT NOT NULL,
  elements JSONB NOT NULL, -- Array of element objects
  evidence_types JSONB,    -- Required evidence type IDs
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### kc_template_assignments

Links knowledge concepts to their templates.

```sql
CREATE TABLE kc_template_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kc_id UUID NOT NULL REFERENCES knowledge_concepts(id),
  template_id UUID NOT NULL REFERENCES kc_templates(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(kc_id, template_id)
);
```

### evidence_types

Categorization of evidence types for proof matrices.

```sql
CREATE TABLE evidence_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### intake_kc_assignments

Links KCs to specific intakes/matters.

```sql
CREATE TABLE intake_kc_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL,
  kc_id UUID NOT NULL REFERENCES knowledge_concepts(id),
  assigned_by TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(intake_id, kc_id)
);
```

### proof_matrix

Tracks evidence status for each element of assigned KCs.

```sql
CREATE TABLE proof_matrix (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_id UUID NOT NULL,
  kc_id UUID NOT NULL REFERENCES knowledge_concepts(id),
  element_index INTEGER NOT NULL,
  element_text TEXT NOT NULL,
  status TEXT DEFAULT 'MISSING' CHECK (status IN ('MISSING', 'PARTIAL', 'SATISFIED')),
  evidence_notes TEXT,
  evidence_links JSONB DEFAULT '[]',
  updated_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(intake_id, kc_id, element_index)
);
```

---

## Statutes Table

### statutes

Cached statute lookups for quick reference.

```sql
CREATE TABLE statutes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL,
  section TEXT NOT NULL,
  title TEXT,
  content TEXT NOT NULL,
  jurisdiction TEXT DEFAULT 'CA',
  source_url TEXT,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(code, section, jurisdiction)
);
```

---

## Required Extensions

Enable these PostgreSQL extensions in Supabase:

```sql
-- For vector similarity search (RAG)
CREATE EXTENSION IF NOT EXISTS vector;

-- For UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
```

---

## Migration Order

Apply migrations in this order:

1. `004_terminal_rag.sql` - Core Terminal tables
2. `005_terminal_supabase.sql` - Supabase-specific setup
3. `006_statutes_table.sql` - Statutes cache
4. `007_session_enhancements.sql` - Session favorites/archive
5. `008_kc_library.sql` - Knowledge Concepts library
6. `009_add_indexes.sql` - Performance indexes

---

## Supabase Configuration

### Project Settings

| Setting | Value |
|---------|-------|
| Region | Choose closest to users |
| Database Password | Generate strong password |
| API URL | `https://[project-ref].supabase.co` |
| Anon Key | Public key for client |
| Service Role Key | Server-side only (never expose) |

### Storage Buckets

Create one private bucket for document storage:

```sql
INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', false);
```

### Row Level Security (RLS)

RLS policies should be configured to restrict access by `intake_id`. See `010_rls_intake_access.sql` for policy templates.
